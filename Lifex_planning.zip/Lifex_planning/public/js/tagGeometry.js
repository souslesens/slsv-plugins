import Lifex_planning from "./main.js";
import TimelineAnimation from "./timelineAnimation.js";
import filtersWidget from "./filtersWidget.js";

var TagsGeometry = (function() {
    var self = {};
    self.decksMap = {};
    self.coordsMap = {};
    self.drawn = false;
    self.init = function() {
        if (!self.drawn) {
            self.drawAllTags("plan");
            self.drawn = true;
        }
    };


    self.drawAllTags = function(viewType, callback) {
if(Lifex_planning.skipTagGeometry)
    return;

        $("#waitImg").css("display","block")
        UI.message("Loading tags geometry")
        var canvas = self.initCanvas("canvasPlan");
        self.canvasP = { viewType: "plan", canvasId: "canvasPlan", canvas: canvas };


        self.loadStoredCanvas(function(err, canvasJson) {
            if (canvasJson) {
                self.canvasObjects = canvasJson.objects;
                self.canvasP.canvas.loadFromJSON(canvasJson);
                self.canvasP.canvas.renderAll();
                self.drawn = 1;
                UI.message("",true)
                return;
            }

            var filter = "";
            var sqlQuery = "select * from V_JC_tags_coords " + filter;

            self.execSql(sqlQuery, function(err, data) {
                if (err) {
                    return callback(err.responseText);
                }

                self.currentTagsData = data.rows;
                self.canvasP.canvas.clear();
                self.drawDataOnCanvas(self.canvasP, data.rows);

                self.drawn = 1;
                UI.message("",true)
                if (callback) {
                    return callback(null, self.decksMap);

                }



            });
        });

    };

    self.highlightTags = function(selectedTags, color, add, callback) {

        if (!color) {
            color = "#b9a06a";
        }
        if (!self.drawn) {
            TagsGeometry.drawAllTags("plan");

        }
        if(Lifex_planning.skipTagGeometry)
            return;

        self.canvasP.canvas.forEachObject(function(obj) {


            if (selectedTags.indexOf(obj.data.tag) > -1) {

                obj.set("fill", color);

            } else {
                if (!add) {
                    obj.set("fill", null);
                }
            }
        });
        self.canvasP.canvas.renderAll();
        if (callback) {
            return callback();
        }


    };



    self.drawDataOnCanvas = function(canvasObj, data) {

        data.sort(function(a, b) {
            var aw = a.y_max - a.y_min;
            var bw = b.y_max - b.y_min;
            if (aw > bw) {
                return -1;
            }
            if (bw > aw) {
                return 1;
            }
            return 0;
        });

        var horCoef = 3;
        var vertCoef = 2;


        self.decksMap = {};
        self.canvasObjects = [];
        data.forEach(function(item, index) {
            item.data = JSON.parse(JSON.stringify(item));
            item.x_min -= 30;
            item.x_max -= 30;
            item.x_min *= horCoef;
            item.y_min *= horCoef;
            item.x_max *= horCoef;
            item.y_max *= horCoef;
            item.z_min *= vertCoef;
            item.z_max *= vertCoef;


            if (item.deck && !self.decksMap[item.deck]) {
                self.decksMap[item.deck] = common.paletteIntense[Object.keys(self.decksMap).length];
            }

        });


        var viewTypes = ["plan", "crossSection"];

        viewTypes.forEach(function(viewType) {
            data.forEach(function(item, index) {

                var w;
                var h;
                var top;
                var left;
                var color = "#ccc";

                var color2 = "rgba(0,0,0,0)";
                var strokeWidth = item.number ? 1.5 : 0.1;

                var color3 = "#555";
                if (viewType == "plan") {
                    w = item.y_max - item.y_min;
                    h = item.x_max - item.x_min;
                    if (w < 1 || h < 1) {
                        top = item.x_max;
                        left = item.y_min;
                    } else {
                        top = item.x_min;
                        left = item.y_min;
                    }
                    color = item.number ? "#72914b" : "#94968c";
                }
                if (viewType == "crossSection") {

                    w = item.y_max - item.y_min;
                    h = item.z_max - item.z_min;
                    top = 700 - item.z_max;
                    left = item.y_min;
                    color = item.number ? "#1244e8" : "#a7cdf1";

                }
                item.index = index;


                if (w < 1 || h < 1) {
                    var dot = new fabric.Circle({
                        radius: horCoef / 2,
                        fill: color,
                        stroke: color,
                        strokeWidth: strokeWidth,
                        top: top,
                        left: left,
                        data: item.data
                    });
                    canvasObj.canvas.add(dot);
                    self.canvasObjects.push(dot);
                } else {
                    const rect = new fabric.Rect({


                        top: top,
                        left: left,
                        width: w,
                        height: h,
                        //  fill: self.disciplineColors[item.disciplineName],
                        fill: color2,
                        // stroke: self.deckColors[item.deck],
                        stroke: color,
                        strokeWidth: strokeWidth,
                        data: item.data
                        // selectable: false
                        // opacity: 0.9
                    });
                    // group.add(rect)
                    canvasObj.canvas.add(rect);
                    self.canvasObjects.push(rect);


                }

            });
        });


        canvasObj.canvas.zoomToPoint({ x: 100, y: 0 }, 1);
        canvasObj.canvas.setZoom(1);
        self.storeCanvas(canvasObj.canvas);

    };
    self.changeKeyIndex = function(obj, keyToMove, newIndex) {

        const entries = Object.entries(obj);
        const currentIndex = entries.findIndex(entry => entry[0] === keyToMove);
        if (currentIndex === -1) {
            console.log(`La clé "${keyToMove}" n'existe pas dans l'objet.`);
            return obj;
        }

        const [entryToMove] = entries.splice(currentIndex, 1);
        entries.splice(newIndex, 0, entryToMove);
        const newObj = Object.fromEntries(entries);

        return newObj;
    };

    self.showObjectInfos = function(object) {


        var html = "<div style='display:inline-grid;padding: 10px 20px;background'>" + "<table class='infosTable'>";
        object.data = self.changeKeyIndex(object.data, "number", 1);
        for (var key in object.data) {
            if (key != "data") {
                var buttonStr = "";
                var value = object.data[key];
                if (key == "number") {

                    value = "<a  href='#' onclick=\" CustomNodeInfos.showNodeInfos('http://totalenergies/resources/tsf/onedata/dalia/jobcard/" + object.data[key] + "');\">" + object.data[key] + "</button>";
                    key = "JobCard";
                }

                var isLink = false;
                var links = ["navigator_link", "link"];
                if (links.includes(key) == true) {
                    isLink = true;
                }
                ;
                if (isLink) {
                    value = `<a href='${object.data[key]}' target='_blank'>${object.data[key]} </a>`;
                }

                html += "<tr class='infos_table'>";
                html +=
                    "<td class='detailsCellName' style='padding: 2px 2px;'>" +
                    key +
                    "</td>";
                html +=
                    "<td class='detailsCellName' style='padding: 2px 2px;'><div class='content'>" +
                    value
                    +
                    "</div></td>";
            }
        }
        $("#Lifex_planning_left_tabs").tabs("option", "active", 2);
        $("#tagsGeometryInfosDiv2").html(html);

    };

    self.execSql = function(sqlQuery, callback) {
        var idDatabase = Lifex_planning.database;
        $.ajax({
            type: "GET",
            url: Config.apiUrl + "/databases/" + idDatabase,
            dataType: "json",

            success: function(data, _textStatus, _jqXHR) {

                var dbName = data.name;
                var sqlType = data.driver;
                const params = new URLSearchParams({
                    type: sqlType,
                    sqlQuery: sqlQuery,
                    name: idDatabase,
                    dbName: dbName
                });

                $.ajax({
                    type: "GET",
                    url: Config.apiUrl + "/kg/data?" + params.toString(),
                    dataType: "json",

                    success: function(data, _textStatus, _jqXHR) {
                        callback(null, data);
                    },
                    error(err) {
                        callback(err);
                    }
                });
            },
            error(err) {
                callback(err);
            }
        });

    };

    self.initCanvas = function(canvasDivId) {
        const canvas = new fabric.Canvas(canvasDivId, {
            // selection :false,
            backgroundColor: "#eee", // 'rgb(100,100,200)',
            selectionColor: "blue",
            selectionLineWidth: 1,
            width: $("#canvas").width(),
            height: $("#canvas").height()
        });

        canvas.on("mouse:wheel", function(opt) {
            var delta = opt.e.deltaY;
            var zoom = canvas.getZoom();
            zoom *= 0.999 ** delta;
            if (zoom > 50) {
                zoom = 50;
            }
            if (zoom < 0.01) {
                zoom = 0.01;
            }
            canvas.setZoom(zoom);
            opt.e.preventDefault();
            opt.e.stopPropagation();
        });

      //  canvas.toggleDragMode(true);
        canvas.on("mouse:down", function(opt) {
            self.currentObject = canvas.getActiveObject();
            $("#Lifex_planning_left_tabs").tabs("option", "active", 2);

            if (self.currentObject) {

                TimelineAnimation.pauseAnimateTimeLine();
                self.showObjectInfos(self.currentObject);
                self.highlightTags([self.currentObject.data.tag], "#af7ede");
                var JCnumber = self.currentObject.data.number;
                //   DataManager.showWBSactivitiesOfJC(JCnumber);
                return;


            }
            return true;
        });
        return canvas;
    };

    const STATE_IDLE = "idle";
    const STATE_PANNING = "panning";
    fabric.Canvas.prototype.toggleDragMode = function(dragMode) {
        // Remember the previous X and Y coordinates for delta calculations
        let lastClientX;
        let lastClientY;
        // Keep track of the state
        let state = STATE_IDLE;
        // We're entering dragmode
        if (dragMode) {
            // Discard any active object
            this.discardActiveObject();
            // Set the cursor to 'move'
            this.defaultCursor = "move";
            // Loop over all objects and disable events / selectable. We remember its value in a temp variable stored on each object
            this.forEachObject(function(object) {
                object.prevEvented = object.evented;
                object.prevSelectable = object.selectable;
                object.evented = false;
                object.selectable = false;
            });
            // Remove selection ability on the canvas
            this.currentWBStaskSelection = false;
            // When MouseUp fires, we set the state to idle
            this.on("mouse:up", function(e) {
                state = STATE_IDLE;


            });
            // When MouseDown fires, we set the state to panning
            this.on("mouse:down", (e) => {
                state = STATE_PANNING;
                lastClientX = e.e.clientX;
                lastClientY = e.e.clientY;

            });
            // When--------------- the mouse moves, and we're panning (mouse down), we continue
            this.on("mouse:move", (e) => {
                if (state === STATE_PANNING && e && e.e) {
                    // let delta = new fabric.Point(e.e.movementX, e.e.movementY); // No Safari support for movementX and movementY
                    // For cross-browser compatibility, I had to manually keep track of the delta

                    // Calculate deltas
                    let deltaX = 0;
                    let deltaY = 0;
                    if (lastClientX) {
                        deltaX = e.e.clientX - lastClientX;
                    }
                    if (lastClientY) {
                        deltaY = e.e.clientY - lastClientY;
                    }
                    // Update the last X and Y values
                    lastClientX = e.e.clientX;
                    lastClientY = e.e.clientY;





                    let delta = new fabric.Point(deltaX, deltaY);
                    this.relativePan(delta);
                    if (this.trigger) {
                        this.trigger("moved");
                    }
                }
            });
        } else {
            // When we exit dragmode, we restore the previous values on all objects
            this.forEachObject(function(object) {
                object.evented = object.prevEvented !== undefined ? object.prevEvented : object.evented;
                object.selectable = object.prevSelectable !== undefined ? object.prevSelectable : object.selectable;
            });
            // Reset the cursor
            this.defaultCursor = "default";
            // Remove the event listeners
            this.off("mouse:up");
            this.off("mouse:down");
            this.off("mouse:move");
            // Restore selection ability on the canvas
            this.currentWBStaskSelection = true;
        }
    };

    self.selectObject = function(key, value, unselect) {
        self.canvas.getObjects().forEach(function(o) {
            if (unselect) {
                self.canvas.setActiveObject(o);
                o.set("stroke", "black");
                o.set("fill", "black");
                o.set("strokeWidth", 0.1);
            }
            if (o.data[key] === value) {
                var stroke = o.get("stroke");
                var strokeW = o.get("strokeWidth");
                self.canvas.setActiveObject(o);
                o.set("stroke", "red");
                o.set("fill", "red");
                o.set("strokeWidth", 4);
            }
            self.selectedObjects.push(o);
        });
        self.canvas.renderAll();
    };
    self.unSelectObjects = function() {
        self.selectedObjects.forEach(function(o) {
            o.set("stroke", "black");
            // o.set("fill", "black")
            o.set("strokeWidth", 0.1);
        });

    };

    self.getCentroid = function(itemData) {
        var centroid = {
            x: (parseFloat(itemData.x_min) + parseFloat(itemData.x_max)) / 2,
            y: (parseFloat(itemData.y_min) + parseFloat(itemData.y_max)) / 2,
            z: (parseFloat(itemData.z_min) + parseFloat(itemData.z_max)) / 2
        };
        return centroid;
    };

    self.pointInsideCircle = function(x, y, cx, cy, radius) {
        const distance =
            Math.sqrt((x - cx) ** 2 + (y - cy) ** 2);
        return distance < radius;
    };

    self.getTagsAroundTag = function(tagId, Hdistance, Vdistance) {
        if (!self.canvasObjectsDataMap) {
            self.canvasObjectsDataMap = {};
            self.canvasObjects.forEach(function(item) {

                self.canvasObjectsDataMap[item.data.tag] = item.data;
            });
        }


        var tagData = self.canvasObjectsDataMap[tagId];
        if (!tagData) {
            return;
        }
        var tagCentroid = self.getCentroid(tagData);
        var tagsAround = [tagData];
        self.canvasObjects.forEach(function(item) {
            if (item.data.tag != tagId) {
                var itemCentroid = self.getCentroid(item.data);
                var ok = self.pointInsideCircle(itemCentroid.x, itemCentroid.y, tagCentroid.x, tagCentroid.y, Hdistance);
                if (ok) {
                    tagsAround.push(item.data);
                }

                /*   if (item.data.x_min >= (tagData.x_min - Hdistance) && item.data.x_max <= (tagData.x_max + Hdistance)) {
                       if (item.data.y_min >= (tagData.y_min - Hdistance) && item.data.y_max <= (tagData.y_max + Hdistance)) {
                           tagsAround.push(item.data)
                       }
                   }*/
            }

        });

        return tagsAround;


    };

    self.selectTagsAroundTag = function() {

        if(!TagsGeometry.currentObject)
            return alert("no tag selected")
        try {
            var tagNumber = TagsGeometry.currentObject.data.tag;
          //  var Hdistance = parseInt($("#tag_neighborhood_radius").val());

            var Hdistance =$( "#tagNeigborhoodSlider" ).slider( "value" )

            var Vdistance = 0;

            if (!tagNumber) {
                alert("No tag position selected ");
            }
            var tagsAround = self.getTagsAroundTag(tagNumber, Hdistance, Vdistance);
            var tagIds = [];
            tagsAround.forEach(function(item) {
                tagIds.push(item.tag);
            });

            self.highlightTags(tagIds, "#00eafd");
            self.highlightTags([tagNumber], "#af7ede", true);


            self.tagsAround = tagsAround;

            // self.highlightTags([tagNumber],"#af7ede")

        } catch (e) {
            alert(e);
        }
    };

    self.getSelectedTags=function() {

        if (self.tagsAround && self.tagsAround.length > 0) {
          return  self.tagsAround
        } else {
            var currentObjects = self.canvasP.canvas.getActiveObjects();
            if (currentObjects.length > 0) {
                var tags=[]
                var tagIds=[]
                currentObjects.forEach(function(item){
                    tags.push(item.data)
                    tagIds.push(item.data.tag)
                })
                self.highlightTags(tagIds,"#00eafd")
                return tags;
            }
            return null;

        }

    }

    self.showTagsAroundTimeLine = function() {
       var tags= self.getSelectedTags();
       if(!tags)
           return alert("no tags Selected");
        DataManager.drawChartFromTags(tags);

    };

 /*  self.clearLocalCache = function() {
        localStorage.removeItem("TagsData");
        localStorage.removeItem("tagsCanvas");
        for (var i = 0; i < 10; i++) {
            localStorage.removeItem("tagsCanvas_" + i);
        }
    };*/

    self.storeCanvas = function(canvasObj) {
        var canvasStr = JSON.stringify(canvasObj.toJSON("data"));

        var payload = {
            dir: "graphs",
            fileName: "tagsCanvas.json",
            data: canvasStr
        };
        $.ajax({
            type: "POST",
            url: Config.apiUrl + "/data/file",
            data: payload,
            dataType: "json",
            success: function(result, _textStatus, _jqXHR) {
                UI.message("canvas saved");
                //  callback();
            },
            error: function(err) {
                alert(err);
            }
        });


    };

    self.loadStoredCanvas = function(callback) {
        var payload = {
            dir: "graphs",
            fileName: "tagsCanvas.json"

        };
        $.ajax({
            type: "GET",
            url: Config.apiUrl + "/data/file",
            data: payload,
            dataType: "json",
            success: function(result, _textStatus, _jqXHR) {
                var canvasJson = JSON.parse(result);
                callback(null, canvasJson);
            },
            error: function(err) {
                callback(err);
            }
        });
    };


    return self;
})
();

export default TagsGeometry;
window.TagsGeometry = TagsGeometry;
