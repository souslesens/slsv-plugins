import GanttSimulation from "./ganttSimulation.js";
import TagGeometry from "./tagGeometry.js";

import FiltersWidget from "./filtersWidget.js";
import CustomNodeInfos from "./customNodeInfos.js";
import DataManager from "./dataManager.js";
import GroupsController from "./groupsController.js";


var Timeline = (function () {
        var self = {};
        

        self.draw = function (sparqlData, refDate, divId, options) {
            var range = {maxTime: 10000, minTime: 10000000000000};
            if (!divId) {
                divId = "JCtimeLineDiv";
            }

            var startDateVarName = "WBS_activity_startDate";// $("#tagsCalendar_startDateSelect").val();
            var endDateVarName = "WBS_activity_endDate";//$("#tagsCalendar_endDateSelect").val();
            var labelVarName = "WBS_activity_label";//$("#tagsCalendar_labelSelect").val();
            var idVarName = "WBS_activity";//$("#tagsCalendar_idSelect").val();
            var groupByVarName = Lifex_planning.groupByKey;

            var currentClassName = "vis-item";//$("#tagsCalendar_classNameSelect").val();

            if (sparqlData.length > 500) {
                currentClassName = "calendar-period-slim";
            }
            if (!startDateVarName) {
                return alert("startDate is mandatory");
            }
            if (!labelVarName) {
                return alert("label is mandatory");
            }
            if (!idVarName) {
                return alert("id is mandatory");
            }


            var data = [];
            var existingIds = {};

            self.groupsMap = {};
            var usedGroups = {};
            var groupsData;

            if (groupByVarName) {
                groupsData = GroupsController.getGroups(Lifex_planning.groupByKey, null);
                groupByVarName = GroupsController.filterGroupsLabelsMap[Lifex_planning.groupByKey];
            } else {
                groupsData = {
                    id: "_",
                    content: "  "
                };
            }
            var varName = GroupsController.getCurrentGroupVarName();
            if (varName == "FunctionalLocation_label") {
                varName = "FunctionalLocationLabel";
            }
            var quantityObj = DataManager.getCurrentQuantityVarName();
            var quantityVarName = quantityObj.varName;

            sparqlData.forEach(function (item) {


                var id = item[idVarName].value;
                var label = item[labelVarName].value;
                //if (!existingIds[id]) {
                existingIds[id] = 1;
                if (id && label && item[startDateVarName]) {

                    var startDate = item[startDateVarName].value;
                    if (true || !startDate instanceof Date) {
                        startDate = startDate.substring(0, 10).replace(/-/g, ".");
                        try {
                            startDate = new Date(startDate);
                        } catch (e) {
                            return;
                        }
                    }
                    var itemClass = currentClassName;

                    if (false && item[varName]) {

                        itemClass = DataManager.legendClassesMap[item[varName].value];
                        if (varName == "WBS_activity_label") {
                            itemClass = DataManager.legendClassesMap[GroupsController.phaseLabelsMap[item[varName].value.split("-")[0]].label];
                        }
                        if (varName == "TaskLabel" || varName == "FunctionalLocationLabel" || varName == "TaskResource_ressourceName") {
                            var wordMatched = "";
                            Object.keys(DataManager.legendClassesMap).forEach(function (legend) {
                                if (legend) {
                                    if (item[varName].value.toLowerCase().includes(legend.toLocaleLowerCase())) {
                                        wordMatched = legend;
                                    }
                                }
                            });
                            if (wordMatched) {
                                itemClass = DataManager.legendClassesMap[wordMatched];
                            }
                        }


                    }

                    var quantity = item[quantityVarName].value;

                    range.minTime = Math.min(range.minTime, startDate.getTime())
                    range.maxTime = Math.max(range.maxTime, startDate.getTime())
                    var obj = {
                        id: id,
                        content: label,
                        start: startDate,
                        className: item?.className || itemClass,
                        quantity: quantity,
                        durationDays: item?.WBS_activity_durationInDays?.value,
                        tags: item?.tags,
                        maximumPOB: item?.JobCardExecution_maximumPOB?.value

                    };


                    if (endDateVarName && item[endDateVarName]) {
                        obj.end = item[endDateVarName].value;
                    }
                    if (groupByVarName && item[groupByVarName]) {
                        //var item_group = item[groupByVarName].value;
                        var groupFn = GroupsController.getGroupFn(Lifex_planning.groupByKey);
                        var groupItem;
                        for (var group in groupsData) {
                            groupItem = groupsData[group];
                            if (groupFn(groupItem.id, item)) {
                                obj.group = groupItem.content;
                                obj.id = obj.id + "_group_" + groupItem.id;
                                if (!usedGroups[groupItem.content]) {
                                    usedGroups[groupItem.content] = 1;
                                }
                            }
                        }


                    } else {
                        obj.group = "_";
                    }
                    data.push(obj);
                } else {
                    var x = 3;
                }
                //}
            });
            data = common.array.sort(data, "startDate");

            data = common.array.unduplicateArray(data, "id");

            if (false || groupByVarName) {
                var groupsDataset = new vis.DataSet();
                var usedGroupsDatasetFormat = Object.keys(usedGroups).map((key, index) => ({
                    id: key,
                    content: key
                }));
                groupsDataset.add(usedGroupsDatasetFormat);
                self.drawTimeLine(data, groupsDataset, divId, range);


            } else {
                self.drawTimeLine(data, null, divId, range);
            }
            // self.timeline.zoomIn(0.5)
            setTimeout(function () {
                //self.timeline.fit()
            }, 500)
            if (refDate) {
                self.timeline.addCustomTime(refDate);
            }
            $("#tagsCalendar_focusDiv").show();
            // common.fillSelectOptions("tagsCalendar_focusOnGroup", groupsData.map(object=>object.id), true);
        };


        self.getGroups = function (sparqlData, groupVarName) {

            var existingIds = {};
            sparqlData.forEach(function (item) {
                var obj = item[groupVarName];
                if (!obj) {
                    return;
                }

                var array = obj.value.split("/");
                if (array.length > 1) {//groups
                    var id = "";
                    array.forEach(function (item2, index) {
                        if (index > 0) {
                            id += "/";
                        }
                        id += item2;//.trim();
                        if (!existingIds[id]) {
                            if (index < array.length - 1) {
                                if (!self.groupsMap[id]) {
                                    self.groupsMap[id] = {id: id, label: item2, contents: [], level: index + 1};
                                }
                                if (index < array.length - 2) {
                                    if (!self.groupsMap[id].nestedGroups) {
                                        self.groupsMap[id].nestedGroups = [];
                                    }
                                    var nestedId = id + "/" + array[index + 1];
                                    if (self.groupsMap[id].nestedGroups.indexOf(nestedId) < 0) {
                                        self.groupsMap[id].nestedGroups.push(nestedId);
                                    }
                                }
                            } else {

                            }
                        }
                    });

                } else {
                    self.groupsMap[obj.value] = {id: obj.value, label: obj.value};
                }

            });
            var groupsData = [];
            for (var key in self.groupsMap) {
                var item = self.groupsMap[key];
                var groupObj = {
                    id: key,
                    treeLevel: item.level,
                    content: item.label
                };
                var expandAll = $("#tagsCalendar_expandGroups").prop("checked");
                if (!expandAll && item.level > 2) {
                    groupObj.showNested = false;
                }


                if (item.nestedGroups && item.nestedGroups.length > 0) {
                    groupObj.nestedGroups = [];

                    item.nestedGroups.forEach(function (nestedGroup) {

                        groupObj.nestedGroups.push(nestedGroup);
                    });
                }

                groupsData.push(groupObj);
            }

            return groupsData;

        };


        self.drawTimeLine = function (items, groups, divId, range) {
            self.currentdataItems = items;


            var container = document.getElementById(divId);
            if (!items) {
                items = self.testData;
            }

            var startDate = "2024-01-01"
            var endDate = "2030-01-01"
            if (false && range) {
                startDate = new Date(range.minTime)

                endDate = new Date(range.minTime)
            }

            if (range) {
                var options = {
                    editable: false,
                    // height: "300px",
                    maxHeight: "850px",

                    //  margin: { item: { vertical: 1 } },
                    verticalScroll:true,
                    groupHeightMode: "fixed",
                    orientation: {axis: "both"},
                    
                    order: function (a, b) {
                        if (a.className > b.className) {
                            return 1;
                        }
                        if (a.className < b.className) {
                            return -1;
                        }
                        return 0;
                    },
                    groupOrder: "content",
                    start: startDate,
                    end: endDate,
                   
                    //  horizontalScroll: true
                    //  preferZoom:true
                };
            }


            for (var key in GanttSimulation.timeLineOptions) {
                options[key] = GanttSimulation.timeLineOptions[key];
            }
         
            try {
                if (self.timeline != null) {
                    try {
                        self.timeline.destroy();
                    } catch (e) {
                        console.log(e);
                    }
                }
                if (groups) {
                    self.timeline = new vis.Timeline(container, items, groups, options);
                } else {
                    self.timeline = new vis.Timeline(container, items, options);
                }


                self.timeline.on("update", function (properties) {
                    GanttSimulation.itemChanged(properties);
                });
                self.timeline.on("itemover", function (properties) {

                    if (GanttSimulation.isSimulationOn) {
                        ;
                    }//  return;


                    if (properties.item) {

                        var data = self.timeline.itemsData.get(properties.item);

                      /*  data.start=new Date(data.start.getTime()+(1000*60*60*24))
                        data.end=new Date(data.end.getTime()+(1000*60*60*24))*/

                        if (data.content) {
                            var html = "<div>Label : " + data.content + "</div>";


                            if (data.start) {
                                html += "<div>Start Date : " + common.getSimpleDateStrFromDate(data.start) + "</div>";


                            //    html += "<div>Start Date : " + data.start.toISOString().split("T")[0] + "</div>";
                            }
                            if (data.end) {
                                html += "<div>End Date : " + common.getSimpleDateStrFromDate(data.end) + "</div>";
                              //  html += "<div>End Date : " + data.end.toISOString().split("T")[0] + "</div>";
                            }
                            if (data.quantity && data.durationDays) {
                                var averagePOB;
                                var yAxisVal = $("#Lifex_planning_quantityVarSelect").val();
                                
                                averagePOB = (data.quantity / data.durationDays)
                                if (yAxisVal.indexOf("1.10") > -1) {
                                    averagePOB=DataManager.getManhoursCoeff(averagePOB);
                                }   
                                averagePOB = parseFloat(DataManager.getPOBfromManHours(averagePOB))
                                

                                html += "<div>Average daily POB : " + averagePOB.toFixed(2) + "</div>";
                            }
                            if (data.maximumPOB) {
                                html += "<div>Declared JC max daily POB : " + data.maximumPOB + "</div>";
                            }
                            if (data.tags) {
                                var tagsStr = data.tags.join(',');
                                html += "<div>Tags : " + tagsStr + "</div>";
                            }
                            PopupMenuWidget.initAndShow(html, "popupMenuWidgetDiv", {
                                Button: properties.event.srcElement,
                                position: "Bottom"
                            },);
                        }
                    }


                });
                self.timeline.on("itemout", function (properties) {

                    PopupMenuWidget.hidePopup("popupMenuWidgetDiv");

                });

                self.timeline.on('rangechange', function (properties) {

                });

                self.timeline.on('rangechanged', function (properties) {

                });

                self.timeline.on("click", function (properties) {
                    if(!properties ||  !properties.item)
                        return;
                    var p = properties.item.lastIndexOf("_group")
                    var uri = properties.item.substring(0, p)

                    self.currentSelectedItem = DataManager.currentWBStasksMap[uri];
                    if(! self.currentSelectedItem.initialDates) {
                        self.currentSelectedItem.initialDates = {
                            start: self.currentSelectedItem.WBS_activity_startDate.value.substring(0,10),
                            end: self.currentSelectedItem.WBS_activity_endDate.value.substring(0,10)
                        }
                    }

                    if (properties.event.altKey ) {
                        // A revoir !!!!!!!!!!!!

                        Simulator.initSimulatorWidget(uri);
                        return;


                    } else if (properties.event.ctrlKey ) {



                        CustomNodeInfos.showNodeInfos(uri);

                    }

                });


            } catch (e) {
                alert(e);
            }


        };


        self.showNodeInfos = function (uri) {
            var dialog = "mainDialogDiv";
            $("#" + dialog).dialog("open");

            CustomNodeInfos.showNodeInfos(uri);
        };
        
        /*self.focusTaskOnGant=function(htmlTdOfTask){
            
            
                var WBS_name=$(htmlTdOfTask).html();
                
                $('.vis-group').children().removeClass('vis-selected');
                var Timeline_data=self.timeline.itemsData.get();
                var result_Timeline_tasks=Timeline_data.filter(item=> item.content==WBS_name);
                if(result_Timeline_tasks?.length==0){
                    return;
                }
                if(result_Timeline_tasks?.length>0){
                    var selected_result;
                    var timeline_value;
                    var max_timeline_value;
                    result_Timeline_tasks.forEach(function(result){
                        timeline_value=parseInt(result.className.split("_")[2]);
                        if(!selected_result){
                            selected_result=result.id;
                            max_timeline_value=timeline_value;
                            
                        }
                        if(timeline_value>max_timeline_value){
                            selected_result=result.id;
                            max_timeline_value=timeline_value;
                        }
                    });
                    if(selected_result){
                        //self.timeline.focus(selected_result);
                        self.timeline.fit( {animation: {
                            duration: 100,
                            easingFunction: 'easeInOutQuad'
                            }});
                        setTimeout(function() {
                            var groups={};
                            var sumGroupHeight=0;
                            $('.vis-labelset').children().each(function(index,groupHTML){
                                var group_name= groupHTML.innerHTML.replace('<div class="vis-inner">','').replace('</div>','');
                                groups[group_name]={length:groupHTML.offsetHeight}
                                sumGroupHeight+=groupHTML.offsetHeight;
                            })
                            self.timeline.focus(selected_result,{
                                animation: {
                                duration: 100,
                                easingFunction: 'easeInOutQuad'
                                }
                            });
                            setTimeout(function() {
                                //scroll To start
                                $('.vis-vertical-scroll')[0].scrollBy(0,-sumGroupHeight);
                                setTimeout(function() {
                                    var item_data=self.timeline.itemsData.get(selected_result);
                                    var group_item=item_data.group;
                                    var scrollToGroup;
                                    var cumul=0;
                                    Object.keys(groups).forEach(function(group){
                                        
                                        if(group==group_item){
                                            scrollToGroup=cumul;
                                        }
                                        cumul+=groups[group].length;
                                    });
                                    // scroll To concerned Group
                                    $('.vis-vertical-scroll')[0].scrollBy(0,scrollToGroup);
                                    setTimeout(function() {
                                        var divOfGroupItem=$('.vis-group').filter(function(){
                                                return $(this).outerHeight()=== groups[group_item].length;
                                        })[1];
                                        var HTMLItem=$(divOfGroupItem).children().filter(function(){
                                                return $(this).html().includes(WBS_name);
                                        });
                                            // enlever les vis-selected
                                        $('.vis-vertical-scroll')[0].scrollBy(0,HTMLItem[0].offsetTop);
                                        $(HTMLItem[0]).addClass('vis-selected');
                                    },300);
                                },300);
                            },300);
                        },300);
                        
                        
                        
                    }
                    
                }
            
            
           
                
                

        }*/
            

        
        return self;


    }


)
();
export default Timeline;
window.Timeline = Timeline;