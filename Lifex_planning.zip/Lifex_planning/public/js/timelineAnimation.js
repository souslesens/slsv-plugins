


var TimelineAnimation = (function() {
    var self = {};
    self.stopAnimation = false;

    self.initTagGeometry = function(range,dayPeriodActivities) {

        self.allTags = [];
        self.stopAnimation = false;
        self.currentAnimationIndex = 0;
        var current_index=0;
        var minDateStr = null;
        var maxDateStr = null;

        self.minDate=range.min;
        self.maxDate=range.max


    };


    self.pauseAnimateTimeLine = function() {
        self.stopAnimation = true;
    };

    self.continueAnimateTimeLine = function() {
        self.stopAnimation = false;
        self.currentTime=Time2dChart.graph2d.getCustomTime().getTime();
        var day = 60 * 60 * 24 * 1000;
        self.currentTime-=day;
        var minDate=self.minDate.getTime();
        if(TagsGeometry.drawn==false){
            return DataManager.onChart2DselectDate({time:self.currentTime});
        }
        


        var currentDay=parseInt(Math.abs(self.currentTime-minDate)/day);
        self.animate(currentDay);

    };

    self.startAnimateTimeLine = function() {
        self.stopAnimation = false;
        self.currentTime = self.minDate.getTime();
        if(TagsGeometry.drawn==false){
            return DataManager.onChart2DselectDate({time:self.minDate});
        }
        
        self.animate(0);

    };

    self.animate = function(index) {
        function sleep(ms) {
            return new Promise(resolve => setTimeout(resolve, ms));
        }

        async function timer() {

            for (var i = (index || 0); i < Object.keys(DataManager.dayPeriodActivities).length
            ; i++) {
                self.currentAnimationIndex = i;
                if (self.stopAnimation) {
                    break;
                }
                await sleep(10);

                var day = 60 * 60 * 24 * 1000;
                self.currentTime += day;
                Time2dChart.graph2d.setCustomTime(self.currentTime);
              //  var date = new Date(self.currentTime).toISOString().replace("T", " ").substring(0, 10);
                var date =  common.getSimpleDateStrFromDate( new Date(self.currentTime))
                $("#tagsCalendarMessageDiv").html(date);
                var dateIso=new Date(self.currentTime);
                var dateStr = dateIso.getFullYear() + "-" + (dateIso.getMonth()+1) + "-" + dateIso.getDate();
                TagsGeometry.highlightTags(DataManager.dayPeriodActivities[dateStr]?.tags, null,function() {
                });
            }
        }


        timer();

    };
    return self;
})();
export default TimelineAnimation
window.TimelineAnimation = TimelineAnimation;