//import SavedQueriesWidget from "../../../../public/vocables/modules/uiWidgets/savedQueriesWidget.js";


//import Sparql_proxy from "../../../../public/vocables/modules/sparqlProxies/sparql_proxy.js";
//import Lifex_planning from "./main.js";

import TimelineAnimation from "./timelineAnimation.js";
import GroupsController from "./groupsController.js";
import Timeline from "./timeline.js";


var Time2dChart = (function () {
        var self = {};
        self.chartdata = []


        self.prepareChartdata = function (groupByKey, callback) {
            var quantityObj = DataManager.getCurrentQuantityVarName();
            self.chartData = DataManager.getCumulatedValuesBydate(quantityObj.varName, quantityObj.fn, quantityObj?.isCumulatedQuantityVar, groupByKey, null);

            if (self.chartData.items.length == 0) {
                return callback("no data found");
            }
            return callback(null, self.chartData)
        }


        self.draw2dChart = function (data, callback) {

            var visjsGroups = new vis.DataSet();
            var groupsArray = [];
            for (var group in data.groups) {
                groupsArray.push(data.groups[group]);
            }
            groupsArray.sort(function (a, b) {
                if (a.content > b.content) {
                    return 1;
                }
                if (a.content < b.content) {
                    return -1;
                }
                return 0;
            });
            var groupLegendMap = {};
            groupsArray.forEach(function (group, index) {
                groupLegendMap[group.id] = group.content;
                group.id = group.content;
                group.className = 'vis-graph-group' + index;

            });
            data.items.forEach(function (item) {
                item.group = groupLegendMap[item.group];
            });
            visjsGroups.add(groupsArray);


            const container = document.getElementById("myChart");


            var options = {
                style: "bar",
                stack: true,
                barChart: {width: 40, align: "center"}, // align: left, center, right
                drawPoints: false,
                height: 250,
                dataAxis: {
                    left: {range: {min: 0}}
                },


                legend: {left: {position: "top-right"}},
                orientation: "top"
                // clickToUse: true

            };

            if (self.graph2d) {
                self.graph2d.destroy();

            }
            // self.graph2d.items=data.items
            self.graph2d = new vis.Graph2d(container, data.items, visjsGroups, options);
            self.graph2d.addCustomTime(new Date(2026, 1, 1));
            var range = self.graph2d.getDataRange();
            TimelineAnimation.initTagGeometry(range, self.dayPeriodActivities);

            self.graph2d.on("contextmenu", function (props) {
                props.event.preventDefault();
            });

            /*self.graph2d.on('doubleClick',function(properties){
                self.onHoverChartBar(properties);
            });*/
            self.graph2d.on('changed', function () {
                /*if (GanttSimulation.isSimulationOn) {
                    return;
                }*/
                $('.vis-bar').off();
                $('.vis-bar').on('mouseenter', function (properties) {
                    var htmlItem = properties.currentTarget;
                    var graph2dEvent = Time2dChart.graph2d.getEventProperties(properties);
                    var time = common.dateToRDFString(graph2dEvent.time);
                    //var time=graph2dEvent.time;
                    if (!time) {
                        return;
                    }
                    try {


                        var group_visjs = $(properties.currentTarget).attr('class').split(' vis-bar')[0] + '-x';
                        var group = Object.keys(DataManager.legendClassesMap).filter(key => DataManager.legendClassesMap[key] == group_visjs);
                        if (!group) {
                            return;
                        }
                    } catch (e) {
                        return;
                    }
                    /*
                    if(group.length>1){
                        var dataItem=Time2dChart.graph2d.itemsData.get({
                            filter: function (item) {
                              return item.x === time
                            }
                          });
                    }*/
                    self.onHoverChartBar(time, group, htmlItem);
                });

            });

            self.graph2d.on("timechange", function (properties) {
                TimelineAnimation.currentTime = properties.time.getTime();

               // var date = new Date(properties.time).toISOString().replace("T", " ").substring(0, 10);
                var date =common.getSimpleDateStrFromDate(new Date(properties.time))
                $("#tagsCalendarMessageDiv").html(date);
            });

            self.graph2d.on("timechanged", function (properties) {
                TimelineAnimation.currentTime = properties.time.getTime();
                self.onChart2DselectDate(properties);
            });

            self.graph2d.on("click", function (properties) {
                if (!properties) {
                    return;
                } else if (properties.what == "legend") {

                } else if (properties.what == "background") {
                    self.onChart2DselectDate(properties);
                }
            });
            setTimeout(function () {
                callback()

            }, 1000);


        };

        self.setChartTitle = function (title) {
            $("#chartTitle").html(title);
        };


        self.onChart2DselectDate = function (properties,options) {
            if(!options){
                options={}
            }
            Timeline.currentTimelineDate=properties;
            TimelineAnimation.pauseAnimateTimeLine();

          //  var date = new Date(properties.time).toISOString().replace("T", " ").substring(0, 10);
            var date =  common.getSimpleDateStrFromDate( new Date(properties.time))


            var dateStr = properties.time.getFullYear() + "-" + (properties.time.getMonth() + 1) + "-" + properties.time.getDate();


            var timeContent = DataManager.dayPeriodActivities[dateStr];


            var scaleArray = [];

            function getClass(value) {

                var classIndex = 0;
                if (!value) {
                    return null;
                }

                for (var i = 0; i <= 5; i++) {

                    if (value > scaleArray[i]) {
                        classIndex = i;

                    }
                }
                return "timeLine_value_" + (classIndex + 1);
            }

            if (timeContent) {


                $("#tagsCalendarMessageDiv").html(date);
                var selection = [];
                var listItems = [];
                var tags = {};
                var totalYvalues = 0;
                var totalDays = 0;
                var coeff = ''
                var yAxisVal = $("#Lifex_planning_quantityVarSelect").val();
                if (yAxisVal.indexOf("1.10") > -1) {
                    coeff = '_110';
                }


                DataManager.sparqlData.forEach(function (item) {
                    var activity = timeContent.activitiesMap[item["WBS_activity"].value];
                    if (activity) {
                        //  if (activities.indexOf(item["WBS_activity"].value) > -1) {

                        if (item.tags) {
                            item.tags.forEach(function (tag) {
                                tags[tag] = 1
                            })

                        }
                        item.dailyYvalue = parseFloat(activity.yValue) / activity.days;
                        totalYvalues += parseFloat(activity.yValue);
                        totalDays += activity.days;
                        selection.push(item);
                        /*
                        listItems.push({
                            id: item["WBS_activity"].value,
                            label: item["WBS_activity_label"].value + '_Mh_' + item['WBS_activity_sumManHours' + coeff].value + '_Days_' +
                                item.WBS_activity_durationInDays.value// + " " + item["WBS_activity_startDate"].value.substring(0, 10) + " " + item["WBS_activity_endDate"].value.substring(0, 10)
                            //   label: item["WBS_activity_startDate"].value.substring(0, 10) + " " + item["WBS_activity_endDate"].value.substring(0, 10)
                        });*/
                    } else {

                    }


                });

                var totalVDailyYvalues = totalYvalues / totalDays;
                for (var i = 1; i <= 5; i++) {
                    scaleArray.push((totalVDailyYvalues / 5) * i);
                }

                selection.forEach(function (item) {
                    item.className = getClass(item.dailyYvalue);
                });


                TagsGeometry.highlightTags(Object.keys(tags));

                // Timeline.draw(selection, date);
                if(!options.notDrawGant){
                    Timeline.draw(selection, null);
                }
                
                
                $("#LifexPlanning_right_tabs").tabs("option", "active", 1);

                DataManager.showWBStasksList(selection, dateStr)


                /*   common.array.sort(listItems, "label");
                   listItems = common.array.unduplicateArray(listItems, "id");
                   common.fillSelectOptions("tagsCalendarItemsSelect", listItems, null, "label", "id");*/
            }
        };


        self.showWBSactivitiesOnGraph2D = function (listItems) {

            if (self.graph2dCustomtimesIds) {
                self.graph2dCustomtimesIds.forEach(function (id) {
                    if (id) {
                        self.graph2d.removeCustomTime(id);
                    }
                });
            }

            self.graph2dCustomtimesIds = [];


            listItems.forEach(function (item) {
                var cssId = "JCTime";
                var time = item.startDate;
                var id = self.graph2d.addCustomTime(time, cssId + " " + item.label);
                self.graph2d.setCustomTimeMarker(item.label, id, true);
                self.graph2dCustomtimesIds.push(id);


            });


        };

        self.onHoverChartBar = function (time, group, htmlItem) {
            var quantityValue;
            // get closiest timetick
            var timestamp = new Date(time);
            timestamp.setHours(22, 59, 59);
            var timestampCorresponding = timestamp.getTime() + 999;
            var correspondingDate = DataManager.periodTicks[timestampCorresponding];
            if (correspondingDate == undefined) {
                timestamp.setHours(23, 59, 59);
                timestampCorresponding = timestamp.getTime() + 999;
                var correspondingDate = DataManager.periodTicks[timestampCorresponding];
                if (correspondingDate == undefined) {
                    timestamp.setHours(0, 59, 59);
                    timestampCorresponding = timestamp.getTime() + 999;
                    var correspondingDate = DataManager.periodTicks[timestampCorresponding];
                    if (correspondingDate == undefined) {
                        return console.log('22/23and00 not working');
                    }
                }
            }

            for (var chartGroup in self.chartData.groups) {
                if (self.chartData.groups[chartGroup].content == group) {
                    quantityValue = self.chartData.groups[chartGroup].data[timestampCorresponding]?.cumul;

                }
            }
            if (quantityValue) {
                var html = "<div> " + group + " value:" + quantityValue.toFixed(2) + " date " + time + "</div>";
                PopupMenuWidget.initAndShow(html, "popupMenuWidgetDiv", {Button: htmlItem});
            } else {
                return;
            }

        }


        return self;

    }


)
();

export default Time2dChart;
window.Time2dChart = Time2dChart;