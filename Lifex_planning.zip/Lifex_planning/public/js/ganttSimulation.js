import Simulator from "./simulator.js";
import Time2dChart from "./time2dChart.js";

var GanttSimulation = (function () {
    var self = {};
    self.simulationData = {}
    self.isSimulationOn = false
    self.WBSbeforeSimulation={}

    var editable = true;
    if (self.isSimulationOn) {
        editable = {
            add: false,         // add new items by double tapping
            updateTime: true,  // drag items horizontally
            updateGroup: false, // drag items from one group to another
            remove: false,       // delete an item by tapping the delete button top right
            overrideItems: true  // allow these options to override item.editable
        };
    }

    self.timeLineOptions = {
        editable: editable,
        timeAxis: {scale: 'day', step: 5},

        onMoving: function (item, callback) {
            if (self.isSimulationOn) {
                return callback(item);
            }
                return callback(null);

        }
        ,
            onMove: function (item, callback) {


                var title = 'Do you really want to move the item to\n' +
                    'start: ' + item.start + '\n' +
                    'end: ' + item.end + '?';
                if (!self.isSimulationOn) {
                    $("#GanttSimulation_infosDiv").html("Simulation is Off, cannot move dates")
                    return callback(null);
                }
                var ok = true;// = confirm('Move item' + title)
                if (ok) {
                    var startDate = item.start;
                    var endDate = item.end;
                    var WBStaskId = item.id.replace(/_group.*/, "")
                    var simulatedDataMap = {
                        [WBStaskId]: {
                            WBS_activity_startDate: startDate,
                            WBS_activity_endDate: endDate
                            //  WBS_activity_startDate:startDate,
                        }


                    };
                    var groupByKey = $("#Lifex_planning_SplitBySelect").val();
                    FiltersWidget.draw2dChart(groupByKey, null, {simulatedDataMap: simulatedDataMap}, function (err, resul) {




                    });
                    var duration=parseFloat(Timeline.currentSelectedItem.WBS_activity_durationInDays.value).toFixed(0)
                    var newDuration =((item.end - item.start) / (24 * 60 * 60 * 1000))
                    var newDailyValue = Math.round( Timeline.currentSelectedItem.dailyYvalue*(duration/newDuration) * 100) / 100;
                    var simulationItem = {
                        wbsLabel: item.content,
                        quantity: parseInt(item.quantity),
                        startDate: Timeline.currentSelectedItem.initialDates.start,
                        newStartDate: common.getSimpleDateStrFromDate(item.start),
                        // newStartDate:item.start.toISOString().substring(0, 10),
                        endDate: Timeline.currentSelectedItem.initialDates.end,
                        newEndDate: common.getSimpleDateStrFromDate(item.end),
                        // newEndDate:item.end.toISOString().substring(0, 10),
                        duration: duration,
                        newDuration: Math.round(newDuration*10)/10,
                        dailyValue: Timeline.currentSelectedItem.dailyYvalue.toFixed(2),
                        newDailyValue: newDailyValue,


                    }
                    self.simulationData[item.id] = simulationItem
                    Time2dChart.onChart2DselectDate(Timeline.currentTimelineDate,{notDrawGant:true});

                    callback(item); // send back item as confirmation (can be changed)
                } else {
                    callback(null); // cancel editing item
                }

            }
            /*  onAdd: function(item, callback) {
                  var value=prompt('Enter text content for new item:')
                      if (value) {
                          item.content = value;
                          callback(item); // send back adjusted new item
                      } else {
                          callback(null); // cancel item creation
                      }


              },
              onMove: function(item, callback) {



                  return   callback(item)
                  var title = 'Do you really want to move the item to\n' +
                      'start: ' + item.start + '\n' +
                      'end: ' + item.end + '?';
                 var ok=confirm(title)
                      if (ok) {
                          callback(item); // send back item as confirmation (can be changed)
                      } else {
                          callback(null); // cancel editing item
                      }

              },
              onMoving: function(item, callback) {
                 return callback(item);
                  if (item.start < min) item.start = min;
                  if (item.start > max) item.start = max;
                  if (item.end > max) item.end = max;

                  callback(item); // send back the (possibly) changed item
              },
              onUpdate: function(item, callback) {
                  var value = prompt('Edit items text:')
                      if (value) {
                          item.content = value;
                          callback(item); // send back adjusted item
                      } else {
                          callback(null); // cancel updating the item
                      }


              },

              onRemove: function(item, callback) {
                 var ok=confirm('Do you really want to remove item ' + item.content + '?')
                      if (ok) {
                          callback(item); // confirm deletion
                      } else {
                          callback(null); // cancel deletion
                      }
                  Simulator.onRemoveItem(item,callback)


              }*/

        }


        self.itemChanged = function (properties) {

        }

        self.startSimulation = function () {
            if (Object.keys(self.simulationData).length > 0) {
                if (!confirm("clear currentSimulation data ?")) {
                    self.simulationData = {}
                }
            }

            if (!DataManager.sparqlData) {
                return alert("No data ")
            }
            self.isSimulationOn = true
            $("#GanttSimulation_infosDiv").html("Simulation On")
            self.initialSparqlData = JSON.stringify(DataManager.sparqlData)

            /*  Timeline.timeline.setOptions({editable:{
                      add: false,         // add new items by double tapping
                      updateTime: true,  // drag items horizontally
                      updateGroup: false, // drag items from one group to another
                      remove: false,       // delete an item by tapping the delete button top right
                      overrideItems: true  // allow these options to override item.editable
                  }})*/
            Timeline.timeline.setOptions({editable: true})
            Timeline.timeline.redraw();

            //   Timeline.timeline.zoomIn(0.5)
        }


        self.stopSimulation = function () {
            self.showSimulationTable()
            Timeline.timeline.setOptions({editable: false})
            if (self.initialSparqlData) {
                self.isSimulationOn = false
                $("#GanttSimulation_infosDiv").html("Simulation Off")
                DataManager.sparqlData = JSON.parse(self.initialSparqlData);
                var groupByKey = $("#Lifex_planning_SplitBySelect").val();
                FiltersWidget.draw2dChart(groupByKey, null, null, function (err, result) {




                })
            }
        }

       
        self.showSimulationTable = function () {
            var dataset = []
            for (var key in self.simulationData) {
                var item = self.simulationData[key]
                var line = [
                    item.wbsLabel,
                    item.quantity,
                    item.startDate,
                    item.newStartDate,
                    item.endDate,
                    item.newEndDate,
                    item.duration,
                    item.newDuration,
                    item.dailyValue,
                    item.newDailyValue,


                ]

                dataset.push(line)
            }
            $("#LifexPlanning_right_tabs").tabs("option", "active", 2);
            $("#simulator_wbs_dataTable_wrapper").html("<table id='simulator_wbs_dataTable'></table>")
            Simulator.initSimulationDataTable(dataset)
        }


        return self;
    }


)
    ();

    export default GanttSimulation;
    window.GanttSimulation = GanttSimulation;